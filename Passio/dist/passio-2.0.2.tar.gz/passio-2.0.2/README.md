New Version of Passio!!
-added symbols for Password generator
Stay tuned for next updates
Author`s gmail : ezioauditore206c@gmail.com
